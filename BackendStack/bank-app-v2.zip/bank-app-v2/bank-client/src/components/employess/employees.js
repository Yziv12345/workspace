import React, { Component } from "react";

export default class Employees extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <h1> Employees Page </h1>;
  }
}
