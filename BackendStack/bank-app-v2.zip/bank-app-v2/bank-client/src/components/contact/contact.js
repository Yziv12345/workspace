import React, { Component } from "react";

export default class Contact extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <h1> Contact Page </h1>;
  }
}
